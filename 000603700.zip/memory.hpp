#ifndef MEMORY_HPP
#define MEMORY_HPP

#include <cstdint>

// Constantes de configuration mémoire
constexpr uint8_t B = 8;  // Taille des adresses en bits
constexpr uint16_t MEMORY_SIZE = 256;  // Taille totale de la mémoire
constexpr uint16_t STACK_SIZE = 16;    // Taille de la zone stack
constexpr uint16_t DATA_SIZE = 240;    // Taille de la zone de données

/**
 * Classe représentant la mémoire du processeur virtuel
 */
class Memory {
private:
    uint8_t* MEM;  // Pointeur vers la mémoire
    uint8_t SP;    // Stack Pointer (déplacé de global à membre de classe)

public:
    // Constructeur
    Memory(uint16_t nbytes);
    
    // Destructeur
    ~Memory();
    
    // Surcharge de l'opérateur [] pour la lecture
    uint16_t operator[](uint8_t address) const;
    
    // Classe proxy pour l'écriture
    class MemoryProxy {
    private:
        Memory* memory;
        uint8_t address;
    public:
        MemoryProxy(Memory* mem, uint8_t addr) : memory(mem), address(addr) {}
        
        // Conversion implicite en uint16_t pour la lecture
        operator uint16_t() const;
        
        // Opérateur d'affectation pour l'écriture
        MemoryProxy& operator=(uint16_t value);
    };
    
    // Surcharge de l'opérateur [] pour l'écriture
    MemoryProxy operator[](uint8_t address);
    
    // Fonction pop pour retirer une valeur du stack
    uint16_t pop();
    
    // Fonction push pour ajouter une valeur au stack
    void push(uint16_t value);
    
    // Fonction pour écrire directement en mémoire (utilisée par MemoryProxy)
    void write(uint8_t address, uint16_t value);
    
    // Fonction pour lire directement de la mémoire (utilisée par MemoryProxy)
    uint16_t read(uint8_t address) const;
};

#endif // MEMORY_HPP
