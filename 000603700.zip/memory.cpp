#include "memory.hpp"
#include <iostream>
#include <cstdlib>

using namespace std;

// Constructeur
Memory::Memory(uint16_t nbytes) : SP(STACK_SIZE - 1) {
    MEM = new uint8_t[nbytes];
    for (uint16_t i = 0; i < nbytes; i++) {
        MEM[i] = 0;
    }
}

// Destructeur
Memory::~Memory() {
    delete[] MEM;
}

// Surcharge de l'opérateur [] pour la lecture
uint16_t Memory::operator[](uint8_t address) const {
    return read(address);
}

// Surcharge de l'opérateur [] pour l'écriture
Memory::MemoryProxy Memory::operator[](uint8_t address) {
    return MemoryProxy(this, address);
}

// Conversion implicite en uint16_t pour la lecture
Memory::MemoryProxy::operator uint16_t() const {
    return memory->read(address);
}

// Opérateur d'affectation pour l'écriture
Memory::MemoryProxy& Memory::MemoryProxy::operator=(uint16_t value) {
    memory->write(address, value);
    return *this;
}

// Fonction pour lire directement de la mémoire
uint16_t Memory::read(uint8_t address) const {
    // Vérification des limites
    if (address >= MEMORY_SIZE - 1) {
        cerr << "Erreur : Adresse de lecture hors limites" << endl;
        exit(1);
    }

    // Lecture en little-endian (octet de poids faible en premier)
    uint16_t low_byte = MEM[address];
    uint16_t high_byte = MEM[address + 1];
    return (high_byte << 8) | low_byte;
}

// Fonction pour écrire directement en mémoire
void Memory::write(uint8_t address, uint16_t value) {
    // Vérification des limites
    if (address >= MEMORY_SIZE - 1) {
        cerr << "Erreur : Adresse d'écriture hors limites" << endl;
        exit(1);
    }

    // Écriture en little-endian (octet de poids faible en premier)
    MEM[address] = value & 0xFF;          // Octet de poids faible
    MEM[address + 1] = (value >> 8) & 0xFF; // Octet de poids fort
}

// Fonction push pour ajouter une valeur au stack
void Memory::push(uint16_t value) {
    // Vérification du débordement du stack
    if (SP < 1) {  // On doit avoir assez d'espace pour 2 octets
        cerr << "Erreur : Débordement de stack" << endl;
        exit(1);
    }

    // Décrémentation du stack pointer (le stack croît vers le bas)
    SP -= 2;

    // Écriture de la valeur au nouvel emplacement du stack
    write(SP, value);
}

// Fonction pop pour retirer une valeur du stack
uint16_t Memory::pop() {
    // Vérification que le stack n'est pas vide
    if (SP >= STACK_SIZE - 1) {
        cerr << "Erreur : Stack vide" << endl;
        exit(1);
    }

    // Lecture de la valeur au sommet du stack
    uint16_t value = read(SP);

    // Mise à jour du stack pointer
    SP += 2;

    return value;
}
