#include "register.hpp"

// Constantes pour les limites de valeurs
constexpr int MIN_REGISTER_VALUE = 0;
constexpr int MAX_REGISTER_VALUE = 65535;  // 2^16 - 1, valeur maximale pour un uint16_t

/**
 * Limite une valeur entre MIN_REGISTER_VALUE et MAX_REGISTER_VALUE
 * @param value La valeur à saturer
 * @return La valeur saturée
 */
static uint16_t saturate(int value) {
    return static_cast<uint16_t>(value < MIN_REGISTER_VALUE ? MIN_REGISTER_VALUE : 
                                (value > MAX_REGISTER_VALUE ? MAX_REGISTER_VALUE : value));
}

// Opérateur d'affectation
Register& Register::operator=(uint16_t val) {
    value = val;
    return *this;
}

// Opérateur d'addition
Register& Register::operator+=(uint16_t val) {
    value = saturate(static_cast<int>(value) + val);
    return *this;
}

// Opérateur de soustraction
Register& Register::operator-=(uint16_t val) {
    value = saturate(static_cast<int>(value) - val);
    return *this;
}

// Opérateur de conversion en uint16_t
Register::operator uint16_t() const {
    return value;
}
