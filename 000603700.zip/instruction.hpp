#ifndef INSTRUCTION_HPP
#define INSTRUCTION_HPP

#include <cstdint>

/**
 * Énumération des opcodes possibles
 */
enum class Opcode {
    SETv,    // SET avec valeur numérique
    SETr,    // SET avec registre
    ADDv,    // ADD avec valeur numérique
    ADDr,    // ADD avec registre
    SUBv,    // SUB avec valeur numérique
    SUBr,    // SUB avec registre
    PRINT,   // Affiche la valeur d'un registre
    IFNZ,    // Exécute conditionnellement si registre non nul
    STORE,   // Stocke en mémoire
    LOAD,    // Charge depuis la mémoire
    PUSH,    // Pousse sur la pile
    POP      // Dépile une valeur
};

/**
 * Énumération des types d'opérandes
 */
enum class OperandType {
    NUMERIC,   // Opérande numérique
    REGISTER   // Opérande registre
};

/**
 * Structure représentant une opérande
 */
struct Operand {
    OperandType type;    // Type d'opérande
    uint16_t parsed;     // Valeur de l'opérande
};

/**
 * Structure représentant une instruction complète
 */
struct Instruction {
    Opcode opcode;       // Code d'opération
    Operand operands[2]; // Opérandes (max 2)
};

#endif // INSTRUCTION_HPP
