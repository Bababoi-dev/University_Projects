#ifndef REGISTER_HPP
#define REGISTER_HPP

#include <cstdint>

/**
 * Classe représentant un registre 16 bits
 */
class Register {
private:
    uint16_t value;

public:
    // Constructeur par défaut
    Register() : value(0) {}
    
    // Constructeur avec valeur initiale
    Register(uint16_t val) : value(val) {}
    
    // Opérateur d'affectation
    Register& operator=(uint16_t val);
    
    // Opérateur d'addition
    Register& operator+=(uint16_t val);
    
    // Opérateur de soustraction
    Register& operator-=(uint16_t val);
    
    // Opérateur de conversion en uint16_t
    operator uint16_t() const;
};

#endif // REGISTER_HPP
