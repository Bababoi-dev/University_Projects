#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdint>
#include <algorithm>
#include <array>
#include "memory.hpp"
#include "register.hpp"
#include "instruction.hpp"

using namespace std;

/**
 * Classe représentant le processeur virtuel
 */
class Processor {
private:
    // Registres du processeur virtuel
    array<Register, 4> registers;
    
    // Instance de la mémoire
    Memory memory;

public:
    // Constructeur
    Processor() : memory(MEMORY_SIZE) {}
    
    /**
     * Obtient la valeur d'un registre à partir de son index
     * @param reg_index Index du registre (0=a, 1=b, 2=c, 3=d)
     * @return Référence au registre
     */
    Register& get_register(uint16_t reg_index) {
        if (reg_index < registers.size()) {
            return registers[reg_index];
        } else {
            cerr << "Erreur : Index de registre invalide" << endl;
            exit(1);
        }
    }
    
    /**
     * Analyse et renvoie la valeur d'un opérande
     * @param operand_str La chaîne représentant l'opérande (registre ou valeur)
     * @param type Type d'opérande détecté (sortie)
     * @return La valeur de l'opérande
     */
    uint16_t parse_operand(const string& operand_str, OperandType& type) {
        if (operand_str == "a") {
            type = OperandType::REGISTER;
            return 0;  // Index du registre a
        }
        if (operand_str == "b") {
            type = OperandType::REGISTER;
            return 1;  // Index du registre b
        }
        if (operand_str == "c") {
            type = OperandType::REGISTER;
            return 2;  // Index du registre c
        }
        if (operand_str == "d") {
            type = OperandType::REGISTER;
            return 3;  // Index du registre d
        }
        
        type = OperandType::NUMERIC;
        int operand = stoi(operand_str);  // Convertit la chaîne en entier                       
        return static_cast<uint16_t>(operand);  // Convertit la valeur
    }
    
    /**
     * Exécute un programme à partir d'un fichier
     * @param program_path Chemin du fichier programme à exécuter
     */
    void exec(const string& program_path) {
        ifstream file(program_path);  // Ouvre le fichier programme
        if (!file) {                   // Vérifie si l'ouverture a réussi
            cerr << "Erreur : Impossible d'ouvrir le fichier." << endl;
            return;
        }
        
        string line;               // Ligne courante lue du fichier
        bool skip_next = false;    // Drapeau pour sauter la prochaine instruction (IFNZ)
        
        while (getline(file, line)) {  // Lit chaque ligne du fichier
            if (skip_next) {           // Si l'instruction précédente nous a dit de sauter
                skip_next = false;     // Réinitialise le drapeau
                continue;              // Saute cette instruction
            }
            
            istringstream iss(line);   // Flux pour analyser la ligne
            string opcode_str, reg_str, operand_str;  // Variables pour stocker l'opcode, le registre et l'opérande
            
            // Extraction de l'opcode
            iss >> opcode_str;
            
            // Détermination de l'opcode et du type d'instruction
            Opcode opcode;
            
            if (opcode_str == "SETv") {
                opcode = Opcode::SETv;
            } else if (opcode_str == "SETr") {
                opcode = Opcode::SETr;
            } else if (opcode_str == "ADDv") {
                opcode = Opcode::ADDv;
            } else if (opcode_str == "ADDr") {
                opcode = Opcode::ADDr;
            } else if (opcode_str == "SUBv") {
                opcode = Opcode::SUBv;
            } else if (opcode_str == "SUBr") {
                opcode = Opcode::SUBr;
            } else if (opcode_str == "PRINT") {
                opcode = Opcode::PRINT;
            } else if (opcode_str == "IFNZ") {
                opcode = Opcode::IFNZ;
            } else if (opcode_str == "STORE") {
                opcode = Opcode::STORE;
            } else if (opcode_str == "LOAD") {
                opcode = Opcode::LOAD;
            } else if (opcode_str == "PUSH") {
                opcode = Opcode::PUSH;
            } else if (opcode_str == "POP") {
                opcode = Opcode::POP;
            } else {
                cerr << "Erreur : Opcode inconnu : " << opcode_str << endl;
                continue;
            }
            
            // Création de l'instruction
            Instruction instruction;
            instruction.opcode = opcode;
            
            // Analyse des opérandes selon l'opcode
            switch (opcode) {
                case Opcode::SETv:
                case Opcode::SETr:
                case Opcode::ADDv:
                case Opcode::ADDr:
                case Opcode::SUBv:
                case Opcode::SUBr: {
                    iss >> reg_str >> operand_str;
                    instruction.operands[0].type = OperandType::REGISTER;
                    instruction.operands[0].parsed = parse_operand(reg_str, instruction.operands[0].type);
                    instruction.operands[1].parsed = parse_operand(operand_str, instruction.operands[1].type);
                    break;
                }
                    
                case Opcode::PRINT:
                case Opcode::IFNZ:
                case Opcode::PUSH:
                case Opcode::POP: {
                    iss >> reg_str;
                    instruction.operands[0].type = OperandType::REGISTER;
                    instruction.operands[0].parsed = parse_operand(reg_str, instruction.operands[0].type);
                    break;
                }
                    
                case Opcode::STORE:
                case Opcode::LOAD: {
                    iss >> operand_str >> reg_str;
                    instruction.operands[0].type = OperandType::NUMERIC;
                    instruction.operands[0].parsed = stoi(operand_str);
                    instruction.operands[1].type = OperandType::REGISTER;
                    instruction.operands[1].parsed = parse_operand(reg_str, instruction.operands[1].type);
                    break;
                }
            }
            
            // Exécution de l'instruction
            switch (instruction.opcode) {
                case Opcode::SETv: {
                    get_register(instruction.operands[0].parsed) = instruction.operands[1].parsed;
                    break;
                }
                    
                case Opcode::SETr: {
                    get_register(instruction.operands[0].parsed) = 
                        static_cast<uint16_t>(get_register(instruction.operands[1].parsed));
                    break;
                }
                    
                case Opcode::ADDv: {
                    get_register(instruction.operands[0].parsed) += instruction.operands[1].parsed;
                    break;
                }
                    
                case Opcode::ADDr: {
                    get_register(instruction.operands[0].parsed) += 
                        static_cast<uint16_t>(get_register(instruction.operands[1].parsed));
                    break;
                }
                    
                case Opcode::SUBv: {
                    get_register(instruction.operands[0].parsed) -= instruction.operands[1].parsed;
                    break;
                }
                    
                case Opcode::SUBr: {
                    get_register(instruction.operands[0].parsed) -= 
                        static_cast<uint16_t>(get_register(instruction.operands[1].parsed));
                    break;
                }
                    
                case Opcode::PRINT: {
                    cout << static_cast<uint16_t>(get_register(instruction.operands[0].parsed)) << endl;
                    break;
                }
                    
                case Opcode::IFNZ: {
                    if (static_cast<uint16_t>(get_register(instruction.operands[0].parsed)) == 0) {
                        skip_next = true;
                    }
                    break;
                }
                    
                case Opcode::STORE: {
                    memory[instruction.operands[0].parsed] = 
                        static_cast<uint16_t>(get_register(instruction.operands[1].parsed));
                    break;
                }
                    
                case Opcode::LOAD: {
                    get_register(instruction.operands[1].parsed) = memory[instruction.operands[0].parsed];
                    break;
                }
                    
                case Opcode::PUSH: {
                    memory.push(static_cast<uint16_t>(get_register(instruction.operands[0].parsed)));
                    break;
                }
                    
                case Opcode::POP: {
                    get_register(instruction.operands[0].parsed) = memory.pop();
                    break;
                }
            }
        }
    }
};

/**
 * Fonction principale
 * @param argc Nombre d'arguments
 * @param argv Tableau des arguments
 * @return Code de retour du programme
 */
int main(int argc, char* argv[]) {
    string program_path = "program.txt";  // Chemin du fichier programme par défaut
    
    // Si un argument est fourni, l'utiliser comme chemin du fichier programme
    if (argc > 1) {
        program_path = argv[1];
    }
    
    Processor processor;
    processor.exec(program_path);  // Exécute le programme
    return 0;
}
